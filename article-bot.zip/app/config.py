import os
from dotenv import load_dotenv

load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
NCBI_API_KEY = os.getenv("NCBI_API_KEY", "")  # ixtiyoriy, PubMed uchun (bo'lmasa ham ishlaydi, sekinroq)
NCBI_EMAIL = os.getenv("NCBI_EMAIL", "example@example.com")  # NCBI talab qiladi

GPT_MODEL = os.getenv("GPT_MODEL", "gpt-4o")
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.0-flash")

if not OPENAI_API_KEY:
    print("OGOHLANTIRISH: OPENAI_API_KEY topilmadi (.env fayliga qo'shing)")
if not GEMINI_API_KEY:
    print("OGOHLANTIRISH: GEMINI_API_KEY topilmadi (.env fayliga qo'shing)")
